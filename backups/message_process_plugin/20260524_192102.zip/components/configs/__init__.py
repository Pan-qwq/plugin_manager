"""
Configs 组件
"""
